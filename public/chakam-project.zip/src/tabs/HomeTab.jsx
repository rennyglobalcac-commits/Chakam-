import React, { useState } from 'react';
import { 
  CheckCircle2, Circle, Clock, Flame, Plus, AlertTriangle, 
  Sparkles, ShieldCheck, Lock, Play, ChevronRight, BarChart2, Calendar
} from 'lucide-react';
import { sounds, speakAunty } from '../utils/audio';

export default function HomeTab({
  state,
  score,
  onToggleTask,
  onAddTask,
  onMoveTask,
  onTriggerConsequence,
  onLockMorningPlan,
  onOpenWeeklyReview,
  onOpenMonthlyDashboard
}) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskStartTime, setNewTaskStartTime] = useState('17:00');
  const [newTaskDuration, setNewTaskDuration] = useState(45);
  const [newTaskTag, setNewTaskTag] = useState('Designer');

  const { tasks, morningPriorities, morningPlanLocked, user } = state;

  // Filter tasks if Work Day Mode is active:
  // Work hours 09:00 - 16:00 are blocked out, restricting daytime slots, prioritizing evening sewing/study/reading
  const displayedTasks = tasks.map(task => {
    if (user.workDayMode && task.isWorkShift) {
      return { ...task, title: '🏥 Clinical Shift (Work Day Mode Active - Locked)', duration: 420 };
    }
    return task;
  });

  // Calculate total scheduled hours
  const totalMinutesScheduled = displayedTasks.reduce((acc, t) => acc + (t.duration || 30), 0);
  const totalHoursScheduled = (totalMinutesScheduled / 60).toFixed(1);
  const isOverbooked = totalMinutesScheduled > 24 * 60;

  const handleAddNewTask = (e) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    if (totalMinutesScheduled + Number(newTaskDuration) > 24 * 60) {
      sounds.playStrike();
      alert("Chakam! You cannot schedule more than 24 hours in a day! Stop overcommitting!");
      return;
    }

    const startH = parseInt(newTaskStartTime.split(':')[0]);
    const startM = parseInt(newTaskStartTime.split(':')[1]);
    const endTotalM = startH * 60 + startM + Number(newTaskDuration);
    const endH = Math.floor(endTotalM / 60) % 24;
    const endM = endTotalM % 60;
    const endTime = `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`;

    onAddTask({
      id: `task_${Date.now()}`,
      title: newTaskTitle.trim(),
      startTime: newTaskStartTime,
      endTime: endTime,
      duration: Number(newTaskDuration),
      tag: newTaskTag,
      done: false,
      moveCount: 0,
      deadline: endTime
    });

    sounds.playSuccess();
    setNewTaskTitle('');
    setShowAddModal(false);
  };

  const getTagColor = (tag) => {
    switch (tag) {
      case 'Nurse': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
      case 'Designer': return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
      case 'Friend': return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      default: return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
    }
  };

  return (
    <div className="space-y-5 pb-24 max-w-md mx-auto px-4 pt-3">

      {/* 1. MASTER ACCOUNTABILITY SCORE CARD */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 p-5 shadow-xl shadow-black/60">
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-[10px] font-black tracking-widest uppercase text-red-500 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
              Live Score
            </span>
            <h2 className="text-sm font-black text-white mt-1">Daily Accountability</h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={onOpenWeeklyReview}
              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] font-bold flex items-center gap-1"
              title="Sunday Review"
            >
              <Calendar className="w-3.5 h-3.5 text-rose-400" />
              Review
            </button>
            <button
              onClick={onOpenMonthlyDashboard}
              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] font-bold flex items-center gap-1"
              title="Monthly Progress"
            >
              <BarChart2 className="w-3.5 h-3.5 text-emerald-400" />
              Stats
            </button>
          </div>
        </div>

        <div className="flex items-end justify-between my-2">
          <div>
            <span className="text-4xl font-black text-white tracking-tight">
              {score.total}%
            </span>
            <p className="text-[11px] text-neutral-400 mt-0.5 font-medium">
              {score.total >= 80 ? '🔥 Aunty is pleased! Keep the pressure on!' : 
               score.total >= 50 ? '⚠️ Borderline! One slip away from Clown Mode.' : 
               '🚨 Disgraceful! Stop playing with your goals!'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs font-bold text-amber-400 flex items-center justify-end gap-1">
              <Flame className="w-3.5 h-3.5 text-red-500" />
              {user.strikeCount} Strike{user.strikeCount !== 1 ? 's' : ''}
            </span>
            <span className="text-[10px] text-neutral-500 block">Quota: 1 Appeal / Wk</span>
          </div>
        </div>

        {/* Breakdown Progress Bars */}
        <div className="mt-4 pt-3 border-t border-neutral-800/80 grid grid-cols-2 gap-x-4 gap-y-2 text-[11px]">
          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Tasks (30%)</span>
              <span className="font-bold text-white">{score.taskPct}%</span>
            </div>
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-red-500 h-full rounded-full transition-all duration-500" style={{ width: `${score.taskPct}%` }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Habits (20%)</span>
              <span className="font-bold text-white">{score.habitPct}%</span>
            </div>
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-amber-500 h-full rounded-full transition-all duration-500" style={{ width: `${score.habitPct}%` }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Budget (20%)</span>
              <span className="font-bold text-white">{score.budgetPct}%</span>
            </div>
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${score.budgetPct}%` }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Reading (15%)</span>
              <span className="font-bold text-white">{score.readingPct}%</span>
            </div>
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-500 h-full rounded-full transition-all duration-500" style={{ width: `${score.readingPct}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* 2. MORNING PLANNING CARD */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 text-red-400 rounded-lg text-sm">
              🌅
            </span>
            <div>
              <h3 className="text-xs font-black text-white uppercase tracking-wider">
                Morning Planning Card
              </h3>
              <p className="text-[10px] text-neutral-400 font-medium">Top 3 Non-Negotiable Priorities</p>
            </div>
          </div>

          {morningPlanLocked ? (
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 flex items-center gap-1">
              <Lock className="w-3 h-3" /> Plan Locked
            </span>
          ) : (
            <button
              onClick={onLockMorningPlan}
              className="text-[11px] font-black bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded-lg shadow-sm shadow-red-950 flex items-center gap-1 transition-all active:scale-95"
            >
              <Lock className="w-3 h-3" /> Start Day & Lock
            </button>
          )}
        </div>

        <div className="space-y-2">
          {morningPriorities.map((item, idx) => (
            <div
              key={item.id}
              className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800/80 flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-5 h-5 rounded-full bg-neutral-800 text-neutral-300 text-[10px] font-black flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">{item.title}</p>
                  <p className="text-[10px] text-neutral-400">
                    {item.timeBlock} • {item.duration}m
                  </p>
                </div>
              </div>
              <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-md border shrink-0 ${getTagColor(item.tag)}`}>
                {item.tag}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 3. TIME-BLOCKED TO-DO LIST (VERTICAL TIMELINE) */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>📅</span> Day Schedule Timeline
            </h3>
            <p className="text-[10px] text-neutral-400">
              {totalHoursScheduled}h booked {isOverbooked ? '(⚠️ Overbooked!)' : 'of 24h'}
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="text-[11px] font-bold bg-neutral-800 hover:bg-neutral-700 text-white px-2.5 py-1 rounded-lg border border-neutral-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5 text-red-400" /> Add Task
          </button>
        </div>

        {/* Timeline Items */}
        <div className="relative pl-3 border-l-2 border-neutral-800 space-y-3 my-2">
          {displayedTasks.map((task) => {
            const isMovedWarning = task.moveCount >= 3;
            return (
              <div key={task.id} className="relative group">
                {/* Timeline node */}
                <span className={`absolute -left-[19px] top-3 w-2.5 h-2.5 rounded-full ring-4 ring-neutral-900 ${
                  task.done ? 'bg-emerald-500' : isMovedWarning ? 'bg-red-500 animate-ping' : 'bg-neutral-600'
                }`} />

                <div className={`p-3 rounded-xl border transition-all ${
                  task.done
                    ? 'bg-neutral-950/60 border-neutral-800/60 opacity-60'
                    : isMovedWarning
                    ? 'bg-red-950/30 border-red-600/80 shadow-md shadow-red-950/40'
                    : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                }`}>
                  <div className="flex items-start justify-between gap-2">
                    <button
                      onClick={() => onToggleTask(task.id)}
                      className="mt-0.5 shrink-0 text-neutral-400 hover:text-white"
                    >
                      {task.done ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-500/20" />
                      ) : (
                        <Circle className="w-4 h-4 text-neutral-500 hover:text-red-400" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] font-mono text-neutral-400">
                          {task.startTime} – {task.endTime}
                        </span>
                        <span className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded border ${getTagColor(task.tag)}`}>
                          {task.tag}
                        </span>
                        {task.moveCount > 0 && (
                          <span className={`text-[9px] font-bold px-1.5 rounded ${
                            task.moveCount >= 3 ? 'bg-red-600 text-white animate-pulse' : 'bg-neutral-800 text-amber-400'
                          }`}>
                            Moved {task.moveCount}x {task.moveCount >= 3 ? '⚠️' : ''}
                          </span>
                        )}
                      </div>

                      <p className={`text-xs font-bold mt-1 text-white ${task.done ? 'line-through text-neutral-500' : ''}`}>
                        {task.title}
                      </p>
                    </div>

                    {!task.done && (
                      <div className="flex items-center gap-1 shrink-0">
                        {/* If moved 3+ times, show Chakam Punishment button */}
                        {isMovedWarning ? (
                          <button
                            onClick={() => onTriggerConsequence(task)}
                            className="text-[10px] font-black bg-red-600 text-white px-2 py-1 rounded-md shadow-sm shadow-red-950 animate-bounce"
                          >
                            Chakam! 🚨
                          </button>
                        ) : (
                          <button
                            onClick={() => onMoveTask(task.id)}
                            className="text-[10px] text-neutral-400 hover:text-amber-400 p-1 rounded hover:bg-neutral-800"
                            title="Reschedule / Move"
                          >
                            Reschedule
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ADD TASK MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700 rounded-2xl p-5 shadow-2xl">
            <h3 className="text-sm font-black text-white mb-3">Add Time-Blocked Task</h3>
            <form onSubmit={handleAddNewTask} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1">Task Title:</label>
                <input
                  type="text"
                  required
                  placeholder="E.g. Cut bodice pattern, 15 wound care questions..."
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 mb-1">Start Time:</label>
                  <input
                    type="time"
                    value={newTaskStartTime}
                    onChange={(e) => setNewTaskStartTime(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 mb-1">Duration (Min):</label>
                  <input
                    type="number"
                    min="10"
                    max="300"
                    step="5"
                    value={newTaskDuration}
                    onChange={(e) => setNewTaskDuration(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1">Identity Tag:</label>
                <select
                  value={newTaskTag}
                  onChange={(e) => setNewTaskTag(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                >
                  <option value="Nurse">🩺 Nurse (Career / Clinical)</option>
                  <option value="Designer">🪡 Designer (Sewing / Fashion)</option>
                  <option value="Friend">👥 Friend (Relationships / Ada)</option>
                  <option value="Me">🏡 Me (Apartment / Budget / Reading)</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-black rounded-xl shadow-md shadow-red-950"
                >
                  Add to Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
