import React, { useState, useEffect } from 'react';
import { 
  Stethoscope, Clock, CheckCircle2, Play, Pause, RotateCcw, 
  Plus, ExternalLink, Award, FileText, HeartHandshake, Sparkles 
} from 'lucide-react';
import { sounds, speakAunty } from '../utils/audio';

export default function NurseTab({ state, onUpdateNurse }) {
  const { nurse } = state;
  const [activeTimerSec, setActiveTimerSec] = useState(45 * 60); // 45 minutes study timer
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [studySubject, setStudySubject] = useState('Wound Care Protocol & Clinical Questions');
  const [showAddGoalModal, setShowAddGoalModal] = useState(false);
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [showAddVolModal, setShowAddVolModal] = useState(false);
  const [newVolOrg, setNewVolOrg] = useState('');
  const [newVolHours, setNewVolHours] = useState(3);
  const [newVolNotes, setNewVolNotes] = useState('');

  // Timer countdown hook
  useEffect(() => {
    let interval = null;
    if (isTimerRunning && activeTimerSec > 0) {
      interval = setInterval(() => {
        setActiveTimerSec(sec => sec - 1);
      }, 1000);
    } else if (activeTimerSec === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      sounds.playSuccess();
      speakAunty("Time is up! 45-minute nursing focus session completed! Well done, future Chief Nurse!");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, activeTimerSec]);

  const toggleTimer = () => {
    if (!isTimerRunning) {
      sounds.playSuccess();
      speakAunty("Study session started! No WhatsApp! No phone! Focus!");
    }
    setIsTimerRunning(!isTimerRunning);
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setActiveTimerSec(45 * 60);
  };

  const formatTimer = (totalSec) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const totalVolHours = nurse.volunteering.reduce((acc, v) => acc + v.hours, 0);

  const handleAddGoal = (e) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) return;
    const newG = {
      id: `ng_${Date.now()}`,
      title: newGoalTitle.trim(),
      targetDate: '2026-11-30',
      progress: 0,
      steps: ['Read reference textbook', 'Complete 15 questions', 'Review test rationale']
    };
    onUpdateNurse({
      ...nurse,
      goals: [newG, ...nurse.goals]
    });
    setNewGoalTitle('');
    setShowAddGoalModal(false);
    sounds.playSuccess();
  };

  const handleAddVolunteering = (e) => {
    e.preventDefault();
    if (!newVolOrg.trim()) return;
    const newV = {
      id: `nv_${Date.now()}`,
      title: newVolOrg.trim(),
      date: new Date().toISOString().split('T')[0],
      hours: Number(newVolHours),
      location: 'Lagos, Nigeria',
      notes: newVolNotes.trim() || 'Community health service'
    };
    onUpdateNurse({
      ...nurse,
      volunteering: [newV, ...nurse.volunteering]
    });
    setNewVolOrg('');
    setNewVolNotes('');
    setShowAddVolModal(false);
    sounds.playSuccess();
  };

  return (
    <div className="space-y-5 pb-24 max-w-md mx-auto px-4 pt-3">
      {/* Tab Header Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-cyan-950/60 via-neutral-900 to-neutral-950 border border-cyan-800/40 p-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/30">
              <Stethoscope className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-black text-white">Nurse Career Hub</h2>
              <p className="text-[11px] text-cyan-400 font-semibold">Excellence in Clinical Practice & Global Growth</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-cyan-900/40 text-xs">
          <div>
            <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Volunteering Logged</span>
            <p className="text-base font-black text-cyan-300 mt-0.5">{totalVolHours} Hours</p>
          </div>
          <div>
            <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Focus Target</span>
            <p className="text-base font-black text-white mt-0.5">45m Daily Study</p>
          </div>
        </div>
      </div>

      {/* 45-MINUTE STUDY TIMER CARD */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-5 text-center">
        <div className="flex items-center justify-between mb-2 text-left">
          <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            Focus Study Session
          </span>
          <span className="text-[10px] font-bold bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
            One Task at a Time
          </span>
        </div>

        <p className="text-xs font-bold text-neutral-300 my-1 truncate">
          "{studySubject}"
        </p>

        {/* Big Digit Display */}
        <div className="my-3 py-4 bg-neutral-950 rounded-2xl border border-neutral-800 shadow-inner">
          <span className="text-5xl font-mono font-black tracking-widest text-cyan-400">
            {formatTimer(activeTimerSec)}
          </span>
          <p className="text-[10px] text-neutral-500 mt-1 font-mono uppercase tracking-wider">
            {isTimerRunning ? '⚡ Active Focus Mode • Phone Prohibited' : 'Session Ready'}
          </p>
        </div>

        <div className="flex items-center justify-center gap-3">
          <button
            onClick={toggleTimer}
            className={`flex-1 py-3 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 ${
              isTimerRunning 
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-950' 
                : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-cyan-950'
            }`}
          >
            {isTimerRunning ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            {isTimerRunning ? 'Pause Study Session' : 'Start 45m Focus'}
          </button>
          <button
            onClick={resetTimer}
            className="p-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-xl border border-neutral-700"
            title="Reset Timer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* NURSING GOALS LIST */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
            <span>🎯</span> Clinical Career Goals
          </h3>
          <button
            onClick={() => setShowAddGoalModal(true)}
            className="text-[11px] font-bold bg-neutral-800 hover:bg-neutral-700 text-white px-2.5 py-1 rounded-lg border border-neutral-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" /> New Goal
          </button>
        </div>

        <div className="space-y-3">
          {nurse.goals.map((goal) => (
            <div key={goal.id} className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800/90 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-xs font-bold text-white leading-snug">{goal.title}</h4>
                <span className="text-[10px] font-black text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  {goal.progress}%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-cyan-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${goal.progress}%` }} 
                />
              </div>

              {/* Action Steps */}
              <div className="space-y-1 pt-1">
                {goal.steps?.map((step, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500/60" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* APPLICATIONS & COURSES TRACKER */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-4">
        <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5 mb-3">
          <span>📋</span> Applications & Deadlines
        </h3>
        <div className="space-y-2">
          {nurse.applications.map((app) => (
            <div key={app.id} className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-start justify-between gap-2">
              <div>
                <p className="text-xs font-bold text-white">{app.title}</p>
                <p className="text-[10px] text-neutral-400 mt-0.5">{app.notes}</p>
                <span className="text-[10px] font-mono text-neutral-500 mt-1 block">
                  Deadline: {app.deadline}
                </span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border shrink-0 ${
                app.status === 'Applied' 
                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' 
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              }`}>
                {app.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* VOLUNTEERING LOG */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
            <span>🤝</span> Volunteering Outreach Log
          </h3>
          <button
            onClick={() => setShowAddVolModal(true)}
            className="text-[11px] font-bold bg-neutral-800 hover:bg-neutral-700 text-white px-2.5 py-1 rounded-lg border border-neutral-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" /> Log Hours
          </button>
        </div>

        <div className="space-y-2">
          {nurse.volunteering.map((v) => (
            <div key={v.id} className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-start justify-between gap-2">
              <div>
                <p className="text-xs font-bold text-white">{v.title}</p>
                <p className="text-[10px] text-neutral-400">{v.location} • {v.date}</p>
                <p className="text-[11px] text-neutral-300 mt-1 italic leading-tight">"{v.notes}"</p>
              </div>
              <span className="text-xs font-black text-cyan-400 bg-cyan-950/60 px-2 py-1 rounded-lg border border-cyan-800 shrink-0">
                +{v.hours} hrs
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ADD GOAL MODAL */}
      {showAddGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700 rounded-2xl p-5 shadow-2xl">
            <h3 className="text-sm font-black text-white mb-3">Add Nursing Career Goal</h3>
            <form onSubmit={handleAddGoal} className="space-y-3">
              <input
                type="text"
                required
                placeholder="E.g. Trauma Nursing Certification, Neonatal Care..."
                value={newGoalTitle}
                onChange={(e) => setNewGoalTitle(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddGoalModal(false)}
                  className="flex-1 py-2 bg-neutral-800 text-neutral-300 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black rounded-xl"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD VOLUNTEERING MODAL */}
      {showAddVolModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700 rounded-2xl p-5 shadow-2xl">
            <h3 className="text-sm font-black text-white mb-3">Log Community Outreach</h3>
            <form onSubmit={handleAddVolunteering} className="space-y-3">
              <input
                type="text"
                required
                placeholder="Organization or Outreach name..."
                value={newVolOrg}
                onChange={(e) => setNewVolOrg(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1">Hours Served:</label>
                <input
                  type="number"
                  min="1"
                  max="12"
                  value={newVolHours}
                  onChange={(e) => setNewVolHours(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2 text-xs text-white focus:outline-none"
                />
              </div>
              <textarea
                placeholder="Notes on patients helped or skills practiced..."
                value={newVolNotes}
                onChange={(e) => setNewVolNotes(e.target.value)}
                rows={2}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-2 text-xs text-white focus:outline-none"
              />
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddVolModal(false)}
                  className="flex-1 py-2 bg-neutral-800 text-neutral-300 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black rounded-xl"
                >
                  Log Hours
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
