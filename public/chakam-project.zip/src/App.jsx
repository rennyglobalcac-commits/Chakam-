import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import HomeTab from './tabs/HomeTab';
import NurseTab from './tabs/NurseTab';
import DesignerTab from './tabs/DesignerTab';
import FriendTab from './tabs/FriendTab';
import MeTab from './tabs/MeTab';

// Modals
import AuntyPanicModal from './components/AuntyPanicModal';
import ConsequenceModal from './components/ConsequenceModal';
import DoomScrollModal from './components/DoomScrollModal';
import EveningCheckinModal from './components/EveningCheckinModal';
import AppealsModal from './components/AppealsModal';
import WeeklyReviewModal from './components/WeeklyReviewModal';
import MonthlyDashboardModal from './components/MonthlyDashboardModal';
import SettingsModal from './components/SettingsModal';

import { loadState, saveState, calculateScore } from './utils/storage';
import { sounds, speakAunty } from './utils/audio';

export default function App() {
  const [state, setState] = useState(() => loadState());
  const [currentTab, setCurrentTab] = useState('HOME');

  // Modals state
  const [panicOpen, setPanicOpen] = useState(false);
  const [doomScrollOpen, setDoomScrollOpen] = useState(false);
  const [eveningCheckinOpen, setEveningCheckinOpen] = useState(false);
  const [appealsOpen, setAppealsOpen] = useState(false);
  const [weeklyReviewOpen, setWeeklyReviewOpen] = useState(false);
  const [monthlyDashboardOpen, setMonthlyDashboardOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Active Consequence Trigger State
  const [consequenceModalOpen, setConsequenceModalOpen] = useState(false);
  const [consequenceTargetTask, setConsequenceTargetTask] = useState(null);

  // Auto-save on state change
  useEffect(() => {
    saveState(state);
  }, [state]);

  const score = calculateScore(state);

  // Handlers for Home Tab
  const handleToggleTask = (taskId) => {
    const updatedTasks = state.tasks.map(t => {
      if (t.id === taskId) {
        const nextDone = !t.done;
        if (nextDone) {
          sounds.playSuccess();
        }
        return { ...t, done: nextDone };
      }
      return t;
    });

    setState(prev => ({ ...prev, tasks: updatedTasks }));
  };

  const handleAddTask = (newTask) => {
    setState(prev => ({
      ...prev,
      tasks: [...prev.tasks, newTask]
    }));
  };

  const handleMoveTask = (taskId) => {
    const target = state.tasks.find(t => t.id === taskId);
    if (!target) return;

    const nextCount = (target.moveCount || 0) + 1;
    const updatedTasks = state.tasks.map(t => {
      if (t.id === taskId) {
        return { ...t, moveCount: nextCount };
      }
      return t;
    });

    if (nextCount >= 3) {
      // Trigger Consequence System!
      sounds.playStrike();
      speakAunty("You moved this task three times! Are you still committed to it? Chakam has caught you!");
      setConsequenceTargetTask({ ...target, moveCount: nextCount });
      setConsequenceModalOpen(true);
    } else {
      sounds.playStrike();
    }

    setState(prev => ({ ...prev, tasks: updatedTasks }));
  };

  const handleTriggerConsequence = (task) => {
    sounds.playStrike();
    setConsequenceTargetTask(task);
    setConsequenceModalOpen(true);
  };

  const handleLockMorningPlan = () => {
    sounds.playSuccess();
    speakAunty("Morning priorities locked in! Go conquer your day without excuses!");
    setState(prev => ({ ...prev, morningPlanLocked: true }));
  };

  // Consequence Actions
  const handleDoItNow = (task) => {
    // User chose to do it now immediately
    const updatedTasks = state.tasks.map(t => {
      if (t.id === task.id) return { ...t, moveCount: 0 };
      return t;
    });
    setState(prev => ({ ...prev, tasks: updatedTasks }));
    setConsequenceModalOpen(false);
  };

  const handleRescheduleWithPenalty = (task) => {
    setState(prev => ({
      ...prev,
      user: {
        ...prev.user,
        strikeCount: Math.min(5, prev.user.strikeCount + 1),
        currentLevel: Math.min(5, prev.user.currentLevel + 1)
      }
    }));
  };

  const handleDeleteWithPenalty = (task) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.filter(t => t.id !== task.id),
      user: {
        ...prev.user,
        strikeCount: Math.min(5, prev.user.strikeCount + 1),
        currentLevel: Math.min(5, prev.user.currentLevel + 1),
        clownMode: true
      }
    }));
  };

  const handleResolvePunishment = (proofUrl) => {
    setState(prev => ({
      ...prev,
      user: {
        ...prev.user,
        clownMode: false,
        strikeCount: Math.max(0, prev.user.strikeCount - 1)
      },
      punishmentHistory: [
        {
          id: `ph_${Date.now()}`,
          level: state.user.currentLevel,
          task: consequenceTargetTask?.title || 'Missed task',
          resolved: true,
          date: new Date().toISOString().split('T')[0],
          proof: proofUrl
        },
        ...prev.punishmentHistory
      ]
    }));
    setConsequenceModalOpen(false);
  };

  // Mode Toggles
  const handleToggleWorkMode = () => {
    const next = !state.user.workDayMode;
    if (next) {
      speakAunty("Work Day Mode activated! 9:00 AM to 4:00 PM blocked for clinical shift. Focus on hospital duties!");
    }
    setState(prev => ({
      ...prev,
      user: { ...prev.user, workDayMode: next }
    }));
  };

  const handleToggleVolunteeringMode = () => {
    const next = !state.user.volunteeringDayMode;
    if (next) {
      speakAunty("Volunteering Day Mode activated! Give your best service to the community!");
    }
    setState(prev => ({
      ...prev,
      user: { ...prev.user, volunteeringDayMode: next }
    }));
  };

  const handleToggleGrayscale = () => {
    setState(prev => ({
      ...prev,
      user: { ...prev.user, grayscaleMode: !prev.user.grayscaleMode }
    }));
  };

  const handleToggleClown = () => {
    setState(prev => ({
      ...prev,
      user: { ...prev.user, clownMode: !prev.user.clownMode }
    }));
  };

  // Appeal Resolution
  const handleResolveAppeal = (approved, reason) => {
    setState(prev => ({
      ...prev,
      user: {
        ...prev.user,
        appealUsedThisWeek: true,
        strikeCount: approved ? Math.max(0, prev.user.strikeCount - 1) : Math.min(5, prev.user.strikeCount + 1),
        currentLevel: approved ? Math.max(1, prev.user.currentLevel - 1) : Math.min(5, prev.user.currentLevel + 1),
        clownMode: !approved
      }
    }));
  };

  return (
    <div className={`min-h-screen bg-neutral-950 text-neutral-100 flex flex-col ${state.user.grayscaleMode ? 'grayscale-mode' : ''}`}>
      
      {/* Top Header */}
      <Header
        state={state}
        onToggleWorkMode={handleToggleWorkMode}
        onToggleVolunteeringMode={handleToggleVolunteeringMode}
        onOpenPanic={() => setPanicOpen(true)}
        onOpenDoomScroll={() => setDoomScrollOpen(true)}
        onOpenEveningCheckin={() => setEveningCheckinOpen(true)}
        onOpenAppeals={() => setAppealsOpen(true)}
        onOpenSettings={() => setSettingsOpen(true)}
        onToggleGrayscale={handleToggleGrayscale}
        onToggleClown={handleToggleClown}
      />

      {/* Main Content Pane */}
      <main className="flex-1 w-full max-w-md mx-auto">
        {currentTab === 'HOME' && (
          <HomeTab
            state={state}
            score={score}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onMoveTask={handleMoveTask}
            onTriggerConsequence={handleTriggerConsequence}
            onLockMorningPlan={handleLockMorningPlan}
            onOpenWeeklyReview={() => setWeeklyReviewOpen(true)}
            onOpenMonthlyDashboard={() => setMonthlyDashboardOpen(true)}
          />
        )}

        {currentTab === 'NURSE' && (
          <NurseTab
            state={state}
            onUpdateNurse={(updatedNurse) => setState(prev => ({ ...prev, nurse: updatedNurse }))}
          />
        )}

        {currentTab === 'DESIGNER' && (
          <DesignerTab
            state={state}
            onUpdateDesigner={(updatedDesigner) => setState(prev => ({ ...prev, designer: updatedDesigner }))}
          />
        )}

        {currentTab === 'FRIEND' && (
          <FriendTab
            state={state}
            onUpdateFriends={(updatedFriends) => setState(prev => ({ ...prev, friends: updatedFriends }))}
            onOpenSettings={() => setSettingsOpen(true)}
          />
        )}

        {currentTab === 'ME' && (
          <MeTab
            state={state}
            onUpdateMe={(updatedMe) => setState(prev => ({ ...prev, me: updatedMe }))}
          />
        )}
      </main>

      {/* Bottom 5-Tab Navigation */}
      <Navigation
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        strikeCount={state.user.strikeCount}
        activePunishment={state.user.clownMode || state.user.strikeCount >= 3}
      />

      {/* All Modal Dialogs */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        state={state}
        onUpdateFriends={(friends) => setState(prev => ({ ...prev, friends }))}
        onUpdateUser={(user) => setState(prev => ({ ...prev, user }))}
      />
      <AuntyPanicModal
        isOpen={panicOpen}
        onClose={() => setPanicOpen(false)}
      />

      <ConsequenceModal
        isOpen={consequenceModalOpen}
        task={consequenceTargetTask}
        level={state.user.currentLevel}
        onClose={() => setConsequenceModalOpen(false)}
        onDoItNow={handleDoItNow}
        onReschedule={handleRescheduleWithPenalty}
        onDeleteTask={handleDeleteWithPenalty}
        onValidReason={() => {
          setConsequenceModalOpen(false);
          setAppealsOpen(true);
        }}
        onResolvePunishment={handleResolvePunishment}
      />

      <DoomScrollModal
        isOpen={doomScrollOpen}
        onClose={() => setDoomScrollOpen(false)}
        onLogIntervention={(item) => {
          setState(prev => ({
            ...prev,
            doomScrollLog: [
              { date: new Date().toLocaleString(), ...item },
              ...prev.doomScrollLog
            ]
          }));
        }}
      />

      <EveningCheckinModal
        isOpen={eveningCheckinOpen}
        onClose={() => setEveningCheckinOpen(false)}
        existingReasons={state.stopReasons}
        onSaveCheckin={(newReason) => {
          setState(prev => ({
            ...prev,
            stopReasons: [newReason, ...prev.stopReasons]
          }));
        }}
      />

      <AppealsModal
        isOpen={appealsOpen}
        onClose={() => setAppealsOpen(false)}
        appealUsedThisWeek={state.user.appealUsedThisWeek}
        currentStrikeCount={state.user.strikeCount}
        onResolveAppeal={handleResolveAppeal}
      />

      <WeeklyReviewModal
        isOpen={weeklyReviewOpen}
        onClose={() => setWeeklyReviewOpen(false)}
        state={state}
        accountabilityScore={score}
      />

      <MonthlyDashboardModal
        isOpen={monthlyDashboardOpen}
        onClose={() => setMonthlyDashboardOpen(false)}
        state={state}
        score={score}
      />

    </div>
  );
}
