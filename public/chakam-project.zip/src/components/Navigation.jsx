import React from 'react';
import { Home, Stethoscope, Scissors, Users, User, Flame } from 'lucide-react';

export default function Navigation({ currentTab, onSelectTab, strikeCount, activePunishment }) {
  const tabs = [
    { id: 'HOME', label: 'Home', icon: Home, badge: activePunishment ? '⚠️' : null },
    { id: 'NURSE', label: 'Nurse', icon: Stethoscope, tag: 'Study' },
    { id: 'DESIGNER', label: 'Designer', icon: Scissors, tag: 'Studio' },
    { id: 'FRIEND', label: 'Friend', icon: Users, tag: 'Ada' },
    { id: 'ME', label: 'Me', icon: User, tag: '₦50k' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 backdrop-blur-md border-t border-neutral-800 pb-safe">
      <div className="max-w-md mx-auto px-2 py-1.5 flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-150 active:scale-90 ${
                isActive 
                  ? 'text-red-500 font-extrabold' 
                  : 'text-neutral-400 hover:text-neutral-200 font-semibold'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 text-red-500 stroke-[2.5]' : 'stroke-[1.8]'}`} />
                {tab.badge && (
                  <span className="absolute -top-1 -right-2 text-[10px] animate-bounce">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] tracking-tight mt-0.5 ${isActive ? 'text-red-400 font-bold' : 'text-neutral-400'}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-0.5 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
