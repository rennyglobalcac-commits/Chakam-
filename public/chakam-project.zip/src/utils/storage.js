// Storage and initial seed data for Chakam!
// Persists to localStorage with fallback defaults

const STORAGE_KEY = 'chakam_state_v1';

export const INITIAL_STATE = {
  user: {
    name: "Adaeze",
    role: "Nurse & Fashion Designer",
    accountabilityPartner: "Ada",
    partnerPhone: "+2348031234567",
    partnerBank: "GTBank - 0123456789 (Ada)",
    clownMode: false,
    grayscaleMode: false,
    statusText: "Focused on Nursing & Design",
    strikeCount: 1, // Start with 1 strike so user sees the urgency!
    currentLevel: 1,
    voiceConfessionRecorded: false,
    appealUsedThisWeek: false,
    workDayMode: false,
    volunteeringDayMode: false,
  },
  
  // Morning Top 3 Priorities
  morningPlanLocked: false,
  morningPriorities: [
    { id: 'p1', title: 'Cut bodice pieces for royal blue dress', timeBlock: '17:30 - 18:30', duration: 60, tag: 'Designer', done: false },
    { id: 'p2', title: 'Complete 15 wound care practice questions', timeBlock: '19:00 - 19:45', duration: 45, tag: 'Nurse', done: false },
    { id: 'p3', title: 'WhatsApp check-in with Ada', timeBlock: '13:00 - 13:15', duration: 15, tag: 'Friend', done: true }
  ],

  // Time-Blocked Schedule (Full 24-hr day timeline)
  tasks: [
    { id: 't1', title: 'Morning Routine & Devotion', startTime: '07:00', endTime: '07:30', duration: 30, tag: 'Me', done: true, moveCount: 0, deadline: '07:30' },
    { id: 't2', title: 'Healthy Breakfast & Hydration', startTime: '07:30', endTime: '08:00', duration: 30, tag: 'Me', done: true, moveCount: 0, deadline: '08:00' },
    { id: 't3', title: 'Apartment Reset & Kitchen Sweep', startTime: '08:00', endTime: '08:20', duration: 20, tag: 'Me', done: true, moveCount: 0, deadline: '08:20' },
    { id: 't4', title: 'Read Atomic Habits (Nonfiction)', startTime: '08:20', endTime: '08:40', duration: 20, tag: 'Me', done: true, moveCount: 0, deadline: '08:40' },
    { id: 't5', title: 'Clinical Shift / Work Hours', startTime: '09:00', endTime: '16:00', duration: 420, tag: 'Nurse', done: false, moveCount: 0, isWorkShift: true, deadline: '16:00' },
    { id: 't6', title: 'Power Rest & Decompress', startTime: '17:00', endTime: '17:30', duration: 30, tag: 'Me', done: false, moveCount: 1, deadline: '17:30' },
    { id: 't7', title: 'Sewing Studio: Cut Bodice Pieces', startTime: '17:30', endTime: '18:30', duration: 60, tag: 'Designer', done: false, moveCount: 3, deadline: '18:30' }, // Moved 3 times! Trigger candidate!
    { id: 't8', title: 'Dinner at Home (No Takeaway)', startTime: '18:30', endTime: '19:00', duration: 30, tag: 'Me', done: false, moveCount: 0, deadline: '19:00' },
    { id: 't9', title: 'Nursing Study: Wound Management', startTime: '19:00', endTime: '19:45', duration: 45, tag: 'Nurse', done: false, moveCount: 0, deadline: '19:45' },
    { id: 't10', title: 'Reading Chapter 5 & Summarize', startTime: '20:00', endTime: '20:30', duration: 30, tag: 'Me', done: false, moveCount: 0, deadline: '20:30' },
    { id: 't11', title: 'Plan Tomorrow & Daily Reflection', startTime: '20:30', endTime: '20:45', duration: 15, tag: 'Me', done: false, moveCount: 0, deadline: '20:45' }
  ],

  // Nurse Tab Data
  nurse: {
    goals: [
      { id: 'ng1', title: 'Master Wound Care & Surgical Dressing', targetDate: '2026-10-31', progress: 65, steps: ['Read 10 pages clinical protocol', 'Complete 15 questions', 'Review 5 medication error case studies'] },
      { id: 'ng2', title: 'Advanced Cardiac Life Support (ACLS)', targetDate: '2026-11-15', progress: 40, steps: ['Review ECG rhythm strips', 'Practice Megacode scenarios', 'Mock exam pass > 85%'] },
      { id: 'ng3', title: 'UK NMC CBT Exam Prep', targetDate: '2026-12-10', progress: 25, steps: ['Sign up with Pearson VUE', 'Daily CBT practice questions', 'Drug calculation drills'] }
    ],
    applications: [
      { id: 'na1', title: 'Lagos University Teaching Hospital Clinical Rotation', deadline: '2026-10-25', status: 'Applied', notes: 'Interview scheduled next Tuesday' },
      { id: 'na2', title: 'Red Cross Emergency Response Specialist', deadline: '2026-11-05', status: 'Planning', notes: 'Gathering transcripts & reference letters' }
    ],
    volunteering: [
      { id: 'nv1', title: 'Community Health Screening Outreach', date: '2026-10-04', hours: 4, location: 'Surulere, Lagos', notes: 'Screened 42 elderly patients for hypertension' },
      { id: 'nv2', title: 'Youth First Aid Workshop', date: '2026-09-20', hours: 3, location: 'Yaba Tech Center', notes: 'Taught basic CPR and choking relief' }
    ],
    studySessionsToday: 1,
    focusMinutesToday: 45
  },

  // Designer Tab Data
  designer: {
    projects: [
      { id: 'dp1', name: 'Royal Blue Corset Evening Gown', client: 'Chioma (Wedding Guest)', deadline: '2026-10-18', progress: 60, status: 'In Progress', fabric: 'Duchess Satin & Beaded Lace' },
      { id: 'dp2', name: 'Modern Ankara Peplum Blazer', client: 'Self Collection', deadline: '2026-10-24', progress: 30, status: 'Cutting', fabric: 'Woodin Ankara Wax Print' },
      { id: 'dp3', name: 'Pleated Linen Wide-Leg Trousers', client: 'Bimbo', deadline: '2026-10-30', progress: 10, status: 'Pattern Draft', fabric: 'Heavyweight Sage Linen' }
    ],
    measurements: [
      { id: 'm1', clientName: 'Chioma O.', date: '2026-10-02', bust: 38, waist: 30, hips: 43, shoulder: 15.5, sleeve: 23, dressLength: 58, notes: 'Prefers sweetheart neckline, boned bodice' },
      { id: 'm2', clientName: 'Bimbo A.', date: '2026-09-28', bust: 34, waist: 27, hips: 38, shoulder: 14.5, sleeve: 21, dressLength: 42, notes: 'High-waisted fit, loose crotch depth' },
      { id: 'm3', clientName: 'Self (Adaeze)', date: '2026-10-01', bust: 36, waist: 28, hips: 40, shoulder: 15, sleeve: 22, dressLength: 55, notes: 'Standard fit template' }
    ],
    ideas: [
      { id: 'di1', title: 'Asymmetric neckline with detachable organza puff sleeve', category: 'Evening Wear', date: '2026-10-05' },
      { id: 'di2', title: 'Scraps patchwork tote bag with Nigerian cowrie shell detail', category: 'Sustainable Zero-Waste', date: '2026-10-06' }
    ]
  },

  // Friend Tab Data
  friends: [
    { id: 'f1', name: 'Ada (Accountability Partner)', phone: '+2348031234567', lastContact: '2026-10-07', daysAgo: 1, birthday: '11-14', notes: 'Strict but loving. Will collect ₦500 without mercy!' },
    { id: 'f2', name: 'Chidinma', phone: '+2348029876543', lastContact: '2026-09-29', daysAgo: 9, birthday: '10-22', notes: 'Overdue for a check-in call!' },
    { id: 'f3', name: 'Blessing (Nursing Colleague)', phone: '+2348055551212', lastContact: '2026-10-04', daysAgo: 4, birthday: '12-05', notes: 'Study buddy for CBT exams' },
    { id: 'f4', name: 'Titi (Fabric Vendor)', phone: '+2348071112233', lastContact: '2026-10-06', daysAgo: 2, birthday: '03-18', notes: 'Tejuosho market wholesale connection' }
  ],

  // Me Tab Data
  me: {
    // Budget Tracker (Strictly ₦50,000 monthly cap)
    budget: {
      monthlyLimit: 50000,
      categories: [
        { id: 'b1', name: 'Food and cooking', limit: 16000, spent: 6500 },
        { id: 'b2', name: 'Transport', limit: 8000, spent: 3200 },
        { id: 'b3', name: 'Toiletries & personal care', limit: 4000, spent: 1500 },
        { id: 'b4', name: 'Cleaning & sanitation', limit: 3000, spent: 2800 }, // >80% warning trigger!
        { id: 'b5', name: 'Data / Airtime', limit: 5000, spent: 3500 },
        { id: 'b6', name: 'Giving / Family', limit: 3000, spent: 2000 },
        { id: 'b7', name: 'Social life', limit: 2000, spent: 500 },
        { id: 'b8', name: 'Fashion / Sewing supplies', limit: 4000, spent: 1200 },
        { id: 'b9', name: 'Books', limit: 2000, spent: 0 },
        { id: 'b10', name: 'Savings', limit: 2000, spent: 2000 },
        { id: 'b11', name: 'Miscellaneous', limit: 1000, spent: 400 }
      ],
      transactions: [
        { id: 'tr1', category: 'Food and cooking', amount: 3500, description: 'Vegetables & spices at market', date: '2026-10-06' },
        { id: 'tr2', category: 'Transport', amount: 1200, description: 'BRT card reload', date: '2026-10-07' },
        { id: 'tr3', category: 'Cleaning & sanitation', amount: 2800, description: 'Bleach, detergent & sponge pack', date: '2026-10-05' }
      ]
    },

    // Apartment Tracker ("Stay Home" Goal)
    apartment: {
      targetNightsAtHome: 20,
      nightsAtHomeCurrent: 14,
      nightsAwayCurrent: 4,
      thresholdAlert: false,
      checklist: [
        { id: 'ac1', label: 'Cooked fresh meal at home', done: true },
        { id: 'ac2', label: 'Apartment dishes washed & dried', done: true },
        { id: 'ac3', label: 'Bathroom sanitation & bleach wipe', done: false },
        { id: 'ac4', label: 'Kitchen counters & trash emptied', done: true },
        { id: 'ac5', label: 'Bedroom reset & bed made neatly', done: true },
        { id: 'ac6', label: 'Laundry washed & folded', done: false },
        { id: 'ac7', label: 'Deep cleaning weekend reset', done: false }
      ]
    },

    // Reading Tracker (Nonfiction)
    reading: {
      currentBook: {
        title: "Atomic Habits",
        author: "James Clear",
        totalPages: 320,
        currentPage: 184,
        dailyTarget: 15,
        pagesReadToday: 15,
        startDate: "2026-09-15",
        targetFinishDate: "2026-10-25",
        notes: [
          "You do not rise to the level of your goals. You fall to the level of your systems.",
          "Make it obvious, make it attractive, make it easy, make it satisfying."
        ]
      },
      completedBooks: [
        { title: "Deep Work", author: "Cal Newport", finishedDate: "2026-09-10" }
      ]
    },

    // Habit Tracker
    habits: [
      { id: 'h1', name: 'Drink 2.5L Water Daily', streak: 12, completedToday: true, history: [true, true, true, true, true, true, true] },
      { id: 'h2', name: 'Morning Skincare & Sunscreen', streak: 9, completedToday: true, history: [true, true, true, true, true, true, true] },
      { id: 'h3', name: 'Evening Apartment Reset', streak: 6, completedToday: false, history: [true, true, false, true, true, true, false] },
      { id: 'h4', name: 'Bible Reading & Gratitude Journal', streak: 15, completedToday: true, history: [true, true, true, true, true, true, true] },
      { id: 'h5', name: 'No Phone In Bed After 10:30 PM', streak: 4, completedToday: false, history: [false, true, true, true, true, false, false] }
    ]
  },

  // Consequence & Punishment Bank
  activePunishment: null, // If set, displays modal / lock
  punishmentHistory: [
    { id: 'ph1', level: 1, type: 'Clown Mode', date: '2026-10-02', task: 'Wash clinical scrubs', resolved: true, proof: 'Clown selfie submitted' }
  ],
  
  // Evening Check-in Stop Reasons
  stopReasons: [
    { date: '2026-10-06', reason: 'Phone', notes: 'Scrolled TikTok for 45 mins after shift' },
    { date: '2026-10-05', reason: 'Tired', notes: 'Night shift fatigue' },
    { date: '2026-10-03', reason: 'Poor planning', notes: 'Did not prep sewing patterns earlier' }
  ],

  // Doom-scrolling interventions
  doomScrollLog: [
    { date: '2026-10-07 14:20', choice: 'Read 5 pages', prevented: true },
    { date: '2026-10-05 21:10', choice: 'Stretch', prevented: true }
  ],

  // Badges Earned
  badges: [
    { id: 'b_streak7', title: '7-Day Warrior', icon: '🔥', description: 'Maintained 7 consecutive days of accountability' },
    { id: 'b_budget', title: 'Naira Guardian', icon: '💰', description: 'Kept monthly budget under ₦50,000' },
    { id: 'b_home', title: 'Queen of Her Castle', icon: '🏡', description: 'Achieved 14+ nights resting at home' }
  ]
};

// Load saved state or return initial
export function loadState() {
  if (typeof window === 'undefined') return INITIAL_STATE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_STATE;
    const parsed = JSON.parse(raw);
    return { ...INITIAL_STATE, ...parsed };
  } catch (err) {
    console.warn("Error parsing saved state", err);
    return INITIAL_STATE;
  }
}

// Save state to localStorage
export function saveState(state) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn("Error saving state", err);
  }
}

// Calculate the Master Accountability Score (0 - 100%)
export function calculateScore(state) {
  if (!state) return 0;
  
  // 1. Tasks completed (30%)
  const totalTasks = state.tasks.length;
  const completedTasks = state.tasks.filter(t => t.done).length;
  const taskPct = totalTasks > 0 ? (completedTasks / totalTasks) : 0;
  
  // 2. Habits kept (20%)
  const habits = state.me.habits;
  const habitsDone = habits.filter(h => h.completedToday).length;
  const habitPct = habits.length > 0 ? (habitsDone / habits.length) : 0;
  
  // 3. Budget status (20%)
  const totalSpent = state.me.budget.categories.reduce((acc, c) => acc + c.spent, 0);
  const budgetPct = totalSpent <= state.me.budget.monthlyLimit ? 1.0 : Math.max(0, 1 - ((totalSpent - 50000) / 10000));
  
  // 4. Reading done (15%)
  const readingTarget = state.me.reading.currentBook.dailyTarget;
  const readingDone = state.me.reading.currentBook.pagesReadToday;
  const readingPct = Math.min(1.0, readingDone / readingTarget);
  
  // 5. Apartment tasks (15%)
  const apTasks = state.me.apartment.checklist;
  const apDone = apTasks.filter(a => a.done).length;
  const apPct = apTasks.length > 0 ? (apDone / apTasks.length) : 0;

  const totalScore = Math.round(
    (taskPct * 30) + 
    (habitPct * 20) + 
    (budgetPct * 20) + 
    (readingPct * 15) + 
    (apPct * 15)
  );

  return {
    total: Math.max(0, Math.min(100, totalScore)),
    taskPct: Math.round(taskPct * 100),
    habitPct: Math.round(habitPct * 100),
    budgetPct: Math.round(budgetPct * 100),
    readingPct: Math.round(readingPct * 100),
    apPct: Math.round(apPct * 100),
    phoneDiscipline: 82 // Tracked phone discipline %
  };
}
